file(REMOVE_RECURSE
  "1107.exe"
  "1107.exe.manifest"
  "1107.pdb"
  "CMakeFiles/1107.dir/main.cpp.obj"
  "CMakeFiles/1107.dir/main.cpp.obj.d"
  "lib1107.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/1107.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

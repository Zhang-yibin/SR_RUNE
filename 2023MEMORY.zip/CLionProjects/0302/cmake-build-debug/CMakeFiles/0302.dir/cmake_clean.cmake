file(REMOVE_RECURSE
  "0302.exe"
  "0302.exe.manifest"
  "0302.pdb"
  "CMakeFiles/0302.dir/main.cpp.obj"
  "CMakeFiles/0302.dir/main.cpp.obj.d"
  "lib0302.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/0302.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

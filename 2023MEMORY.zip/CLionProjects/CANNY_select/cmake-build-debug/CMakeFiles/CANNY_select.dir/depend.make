# Empty dependencies file for CANNY_select.
# This may be replaced when dependencies are built.

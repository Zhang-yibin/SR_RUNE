file(REMOVE_RECURSE
  "CANNY_select.exe"
  "CANNY_select.exe.manifest"
  "CANNY_select.pdb"
  "CMakeFiles/CANNY_select.dir/main.cpp.obj"
  "CMakeFiles/CANNY_select.dir/main.cpp.obj.d"
  "libCANNY_select.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/CANNY_select.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
